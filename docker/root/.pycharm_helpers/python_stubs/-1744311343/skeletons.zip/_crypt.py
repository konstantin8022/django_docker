# encoding: utf-8
# module _crypt
# from /usr/lib/python3.5/lib-dynload/_crypt.cpython-35m-x86_64-linux-gnu.so
# by generator 1.145
# no doc
# no imports

# functions

def crypt(*args, **kwargs): # real signature unknown
    """
    Hash a *word* with the given *salt* and return the hashed password.
    
    *word* will usually be a user's password.  *salt* (either a random 2 or 16
    character string, possibly prefixed with $digit$ to indicate the method)
    will be used to perturb the encryption algorithm and produce distinct
    results for a given *word*.
    """
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is ''

__spec__ = None # (!) real value is ''

